function m=I
%Identity matrix for the variance in a model formula, same as I=random(1).
m=random(1);