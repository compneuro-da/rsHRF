function c=char(t)
c=t.names;