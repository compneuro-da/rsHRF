function [x,v]=double(m);
x=double(m.mean);
v=double(m.variance);