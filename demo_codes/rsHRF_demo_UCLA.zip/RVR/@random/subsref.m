function t=subsref(m.s)
t=getfield(m,s.subs);